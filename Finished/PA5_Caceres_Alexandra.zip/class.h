#include <iostream>
#include "string_library.h"
using namespace std;

#ifndef CLASS_H
#define CLASS_H

class symbol {

public:

symbol();
~symbol();

char* getname();
int getbonusvalue();
bool getbool();

void setname (char*);
void setbonusvalue (int);
void setbool (bool);



void print ();

private:
char* name;
int bonusvalue;
bool exists;


};

#endif
