#include <iostream>
#include "class.h"

using namespace std;

symbol:: symbol()
{
	char* name = NULL;
	int bonusvalue = 0;				// constructor
	bool exists = false;
}

symbol:: ~symbol()
{
	if( name != NULL)
		{				// deconstructor
			delete[] name;
		}
			name = NULL;
			bonusvalue = 0;
			exists = false;
}



char* symbol::getname()
{
	return name;
}

int symbol:: getbonusvalue()
{
	return bonusvalue;
}

bool symbol:: getbool()
{
	return exists; 
}

void symbol::setname(char* reels)
{
	name = reels;
	strlength(reels);
	name = new char[strlength(reels) +1];
	stringcopy (name, reels);
}

void symbol:: setbonusvalue(int newvalue)
{
	newvalue = bonusvalue;
}

void symbol:: setbool (bool newexists)
{
	newexists = exists;
}

void print (class symbol* reel)
{
		cout << (*reel).getname() << " " << (*reel).getbonusvalue() << endl;
}


