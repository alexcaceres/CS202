#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

struct machine {
 char name[10];
 int bonusvalues;
 bool exists;
};

struct reel {          // second added struct
machine rows[10];	// rows of type machine
int stop;


};


void readin( machine* sptr);                                  // function prototypes
void reelfill(reel* rptr, machine* sptr);
void strcopy (char* destination, char* source);
void writescreen (reel* rptr, machine* sptr);
void menu( reel* rptr, machine* sptr);
void findsymbol( reel* rptr, machine* sptr);


int main()
{

srand(time(NULL));     // in order to randomize my slot machine function



reel slot[3];
reel* rptr = slot;			// pointers pointing to my two arrays
machine symbols[6];
machine* sptr = symbols;



readin(sptr);
menu(rptr, sptr);
return 0;

}

void menu( reel* rptr, machine* sptr)
{
int selection;
bool occupied;    // keeps users from choosing a menu option before configurating
do {
        cout << "  Slot machine reel" << endl;
        cout << "  1. Populate a new slot machine " << endl;
        cout << "  2. Print machine configuration to screen"<< endl;
        cout << "  3. Choose reel number (0-2) and stop number from (0-9): " << endl;
cout << "  4. QUIT" << endl;
        cin >> selection;

        switch (selection)
        {
            case 1:       // menu options 
               reelfill(rptr, sptr);
occupied = true;
                break; 
            case 2:
                if(occupied == true)
		{
		writescreen(rptr, sptr); 
		}
	else {
cout << "No slot machine configuration has been chosen. Please choose 1" << endl; }
                break;
       case 3: 
		if(occupied == true)
		{
		findsymbol(rptr, sptr);
		}
		else {
		cout << "No slot machine configuration has been chosen. Please choose 1" << endl; }
	break;
	case 4: cout << "Goodbye! /n";
	exit(8);       // exits the menu and program
	break;
	default: cout << selection << " is not a valid menu item. Please choose a valid number.\n";  // does not allow for a number besides 1-4 to be chosen
        }
    } while (selection != 0 );
}


void readin(machine* sptr)  // reads in the symbols file 
{
	char filename[15];
	char* fptr = filename;                // manually asks for the filename of symbols
	cout << "Enter filename: " << endl;	// reads in the file correctly
	cin >> fptr;
	ifstream fin;
	fin.open(fptr);

		for(int i = 0; i < 6; i++)
		{
		fin >> (*sptr).name >> (*sptr).bonusvalues;
		if((*sptr).bonusvalues != 0)
		{
		(*sptr).exists = true;
		}
		else
		{
		(*sptr).exists = false;
		}
 		cout << (*sptr).name << (*sptr).bonusvalues << endl;
		}

	fin.close();

}

void reelfill (reel* rptr, machine* sptr)
{

	machine * sptr2 = sptr;
	machine* row_ptr = (*rptr).rows; 

 
	for(int i = 0; i < 3; i++)        // loops through to fill the reel
	{					// the program compiles but I recieve garbage
						// I only can read 7 
	for(int j = 0; j < 10; j++)
	{   
 	int number = rand() %6;
	int k=0;
	while(k < number)
	{
	sptr2++;
	k++;
	}

 	strcopy((*row_ptr).name, (*sptr2).name);
	cout << (*row_ptr).name << endl;
 	(*row_ptr).bonusvalues = (*sptr2).bonusvalues;
 	(*row_ptr).exists = (*sptr2).exists;
	int l = 0;
	while(l < number)
	{
	sptr2--;
	l++;
	}
	row_ptr++;
	}
	rptr++;	
      }
}



 void writescreen (reel* rptr, machine* sptr) 
{
	machine* rowptr = (*rptr).rows;

	  for(int i = 0; i < 3; i++)   // writes file to screen
	    {
		for( int j = 0; j < 10; j++)
		{
		cout << (*rowptr).name << endl;
		rowptr++;
		}
	    rptr++;
    	    }
}


void findsymbol(reel* rptr, machine* sptr)   // function to choose a specific symbol and bvalue
{						// same problem, compiles but whichever reel and stop chosen, the value is 7

	int column;
	int row;
	cout << " Choose reel and stop number: ? " << endl; 
	cin >> column >> row;
		if(column > -1 && column < 3 && row > -1 && row < 10)
		{
		cout << "The symbol is: " << (*sptr).name << endl;
		if((*sptr).exists == true)
		{
		cout << "The bonus value is: " << (*sptr).bonusvalues << endl;
		cout << "Bool: " << (*sptr).exists << endl;
		}
			else
			{
			cout << "There is no bonus value." << endl;
			} 
		}
			else
			{ 
			cout << " That is not a valid number" << endl;

			}	
}

void strcopy (char* destination, char* source)
{
	while((*source) != '\0' )    
	{
 	(*destination) = (*source);  
 	//cout << destination << endl;
 	destination++;
 	source++;
	}

	(*destination) = '\0';   // null

//cout << (*destination) << endl;
}
